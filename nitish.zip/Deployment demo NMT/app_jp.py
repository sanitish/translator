#!/usr/bin/env python
# coding: utf-8


from __future__ import absolute_import, division, print_function, unicode_literals

import tensorflow as tf

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from sklearn.model_selection import train_test_split

import unicodedata
import re
import numpy as np
import os
import io
import time

from Encoder_Decoder_classes import Encoder , Decoder , BahdanauAttention


from pickle import load
from pickle import dump


from werkzeug import secure_filename

# load a clean dataset
def load_data(filename):
    print(filename+" Loaded Successfully")
    return load(open(filename, 'rb'))

# Converts the unicode file to ascii
def unicode_to_ascii(s):
  return ''.join(c for c in unicodedata.normalize('NFD', s)
      if unicodedata.category(c) != 'Mn')


def preprocess_sentence(w):
  w = unicode_to_ascii(w.lower().strip())
  
  # creating a space between a word and the punctuation following it
  # eg: "he is a boy." => "he is a boy ."
  # Reference:- https://stackoverflow.com/questions/3645931/python-padding-punctuation-with-white-spaces-keeping-punctuation
  w = re.sub(r"([?.!,¿ーゝゞ、。])", r" \1 ", w)
  
  w = re.sub(r'[" "]+', " ", w)
  
  # replacing everything with space except (a-z, A-Z, ".", "?", "!", ",")
  w = re.sub(r"  ", " ", w)
  
  w = w.rstrip().strip()
  
  # adding a start and an end token to the sentence
  # so that the model know when to start and stop predicting.
  w = '<start> ' + w + ' <end>'
  return w

sample_output = load_data("sample_output")
sample_hidden = load_data( "sample_hidden")
sample_decoder_output = load_data( "sample_decoder_output")
enc_req = load_data("enc_req")
inp_lang  = load_data("inp_lang")
targ_lang = load_data("targ_lang")
enc_hidden = load_data("enc_hidden")

enc_req_keys = ['vocab_inp_size', 'embedding_dim', 'units', 'BATCH_SIZE','max_length_targ', 'max_length_inp']
vocab_inp_size, embedding_dim, units, BATCH_SIZE ,max_length_targ, max_length_inp = [enc_req[i] for i in enc_req_keys]
vocab_tar_size = len(targ_lang.word_index)+1

encoder = Encoder(vocab_inp_size, embedding_dim, units, BATCH_SIZE)
print ('Encoder output shape: (batch size, sequence length, units) {}'.format(sample_output.shape))
print ('Encoder Hidden state shape: (batch size, units) {}'.format(sample_hidden.shape))

attention_layer = BahdanauAttention(10)
attention_result, attention_weights = attention_layer(sample_hidden, sample_output)
print("Attention result shape: (batch size, units) {}".format(attention_result.shape))
print("Attention weights shape: (batch_size, sequence_length, 1) {}".format(attention_weights.shape))

decoder = Decoder(vocab_tar_size, embedding_dim, units, BATCH_SIZE)
print ('Decoder output shape: (batch_size, vocab size) {}'.format(sample_decoder_output.shape))

optimizer = tf.keras.optimizers.Adam()
loss_object = tf.keras.losses.SparseCategoricalCrossentropy(
    from_logits=True, reduction='none')

def loss_function(real, pred):
  mask = tf.math.logical_not(tf.math.equal(real, 0))
  loss_ = loss_object(real, pred)

  mask = tf.cast(mask, dtype=loss_.dtype)
  loss_ *= mask

  return tf.reduce_mean(loss_)

checkpoint_dir = './training_checkpoints'
checkpoint_prefix = os.path.join(checkpoint_dir, "ckpt")
checkpoint = tf.train.Checkpoint(optimizer=optimizer,
                                 encoder=encoder,
                                 decoder=decoder)

def evaluate(sentence):
  attention_plot = np.zeros((max_length_targ, max_length_inp))

  sentence = preprocess_sentence(sentence)

  inputs = [inp_lang.word_index[i] for i in sentence.split(' ')]
  inputs = tf.keras.preprocessing.sequence.pad_sequences([inputs],
                                                         maxlen=max_length_inp,
                                                         padding='post')
  inputs = tf.convert_to_tensor(inputs)

  result = ''

  hidden = [tf.zeros((1, units))]
  enc_out, enc_hidden = encoder(inputs, hidden)

  dec_hidden = enc_hidden
  dec_input = tf.expand_dims([targ_lang.word_index['<start>']], 0)

  for t in range(max_length_targ):
    predictions, dec_hidden, attention_weights = decoder(dec_input,
                                                         dec_hidden,
                                                         enc_out)

    # storing the attention weights to plot later on
    attention_weights = tf.reshape(attention_weights, (-1, ))
    attention_plot[t] = attention_weights.numpy()

    predicted_id = tf.argmax(predictions[0]).numpy()

    result += targ_lang.index_word[predicted_id] + ' '

    if targ_lang.index_word[predicted_id] == '<end>':
      return result, sentence, attention_plot

    # the predicted ID is fed back into the model
    dec_input = tf.expand_dims([predicted_id], 0)

  return result, sentence, attention_plot

# function for plotting the attention weights

def plot_attention(attention, sentence, predicted_sentence):
  print(sentence)# = [i.decode('utf-8') for i in sentence ]  
  fig = plt.figure(figsize=(10,10))
  ax = fig.add_subplot(1, 1, 1)
  ax.matshow(attention, cmap='viridis')
    
  #fp = matplotlib.font_manager.FontProperties(fname=os.path.expanduser('~/Library/Fonts/ipaexg.ttf'))
  #plt.rcParams['font.family'] = fp.get_name()

  fontdict = {'fontsize': 14}
  #fontdict_jap = {'fontsize': 14 , font_family:'Aozora Mincho'}
  #sentence = [str(s, "utf-8") for s in sentence]
  ax.set_xticklabels([''] + sentence, fontdict=fontdict , rotation=90)
  ax.set_yticklabels([''] + predicted_sentence, fontdict=fontdict)

  ax.xaxis.set_major_locator(ticker.MultipleLocator(1))
  ax.yaxis.set_major_locator(ticker.MultipleLocator(1))

  plt.show()
    
def translate(sentence):
  #sentence=japTok(sentence)
  result, sentence, attention_plot = evaluate(sentence)

  print('Input: %s' % (sentence))
  print('Predicted translation: {}'.format(result))

  attention_plot = attention_plot[:len(result.split(' ')), :len(sentence.split(' '))]
  #plot_attention(attention_plot, sentence.split(' '), result.split(' '))
  return result

# restoring the latest checkpoint in checkpoint_dir
checkpoint.restore(tf.train.latest_checkpoint(checkpoint_dir))

import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
import nagisa


app = Flask(__name__)
#model = pickle.load(open('model.pkl', 'rb'))
print("Started Flask")
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():

#     int_features = [int(x) for x in request.form.values()]
#     final_features = [np.array(int_features)]
    
    jpn_raw=request.form['jpn']
    words = nagisa.tagging(jpn_raw)
    jpn = " ".join(words.words)
    prediction = translate(jpn)

    output = prediction[:-6]#round(prediction[0], 2)

    return render_template('index.html', prediction_text=' {}'.format(output))

@app.route('/results',methods=['POST'])
def results():

    data = request.get_json(force=True)
    prediction = model.predict([np.array(list(data.values()))])

    output = prediction[0]
    return jsonify(output)

if __name__ == "__main__":
    app.run(debug=True)



# #route for uploadfile
# @app.route('/upload')
# def upload_file():
#    return render_template('upload.html')
	
# @app.route('/uploader', methods = ['GET', 'POST'])
# def upload_file():
#    if request.method == 'POST':
#       f = request.files['file']
#       f.save(secure_filename(f.filename))
#       return 'file uploaded successfully'
		
# if __name__ == '__main__':
#    app.run(debug = True)